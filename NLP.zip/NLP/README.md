
# Misinformation Detection Software

Software that will verify claims as valid or invalid based on claims in the Fever dataset.


## Installation

Install the libraries as they are required for the project
-pip install django
-pip install django-binary-database-files
-pip install scikit-learn
-pip install transformers
-pip install torch
-pip install seaborn
-In the occurence of any errors, please install with pip install library

    
## Deployment

To deploy this project run
-cd nlpProject
-python manage.py runserver

